<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Mutasi Keluar - Add Missing Indexes
        Schema::table('mutasi_keluar', function (Blueprint $table) {
            // Index for Soft Deletes (deleted_at is checked in every query)
            $table->index('deleted_at');
        });

        // Mutasi Masuk - Add Missing Indexes
        Schema::table('mutasi_masuk', function (Blueprint $table) {
            $table->index('deleted_at');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('mutasi_keluar', function (Blueprint $table) {
            $table->dropIndex(['deleted_at']);
        });

        Schema::table('mutasi_masuk', function (Blueprint $table) {
            $table->dropIndex(['deleted_at']);
        });
    }
};
